survival-skills
===============

## To run the App
- Run `npm install`
- Run the server: `npm start`
- Test the server: `grunt test` in a new terminal window