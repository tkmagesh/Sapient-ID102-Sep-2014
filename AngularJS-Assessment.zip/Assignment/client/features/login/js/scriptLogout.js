'use strict';
    if(typeof(Storage) !== 'undefined') {
         localStorage.removeItem('role');
    }